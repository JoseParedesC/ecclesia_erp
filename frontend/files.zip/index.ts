// ============================================
// features/journalVoucher/index.ts
// ============================================

export { JournalVouchersPage }  from './pages/JournalVouchersPage';
export { journalVoucherService } from './journalVoucher.service';
export { useJournalVouchers, useCreateVoucher, usePostVoucher, useCancelVoucher } from './hooks/useJournalVouchers';
export { VoucherStatusBadge }   from './components/VoucherStatusBadge';
export { VoucherTypeBadge }     from './components/VoucherTypeBadge';
export { isBalanced, lineTotals, VOUCHER_TYPE_LABELS, VOUCHER_STATUS_LABELS } from './journalVoucher.types';
export type { JournalVoucher, JournalVoucherLine, VoucherType, VoucherStatus, LineType, CreateVoucherRequest } from './journalVoucher.types';
